# cf-worker-vless

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build cf-worker-vless` to build the library.

## Running unit tests

Run `nx test cf-worker-vless` to execute the unit tests via [Jest](https://jestjs.io).
