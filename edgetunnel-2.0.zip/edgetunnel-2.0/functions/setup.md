for local env, create `.dev.vars` env file
