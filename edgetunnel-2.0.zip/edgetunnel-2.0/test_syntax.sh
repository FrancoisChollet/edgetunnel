if [[ $uuid ]]; then
            echo "skip tf mask"
          else
            echo "enable tf mask"
          fi