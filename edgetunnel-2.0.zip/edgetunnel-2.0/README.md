# Edge Tunnel（Beta）

Running **V2ray** in the edge.

# Documentation

https://edgetunnel.114567.xyz/

# Feedback and Communication

If you have any questions, please use https://t.me/edgetunnel for communication.
